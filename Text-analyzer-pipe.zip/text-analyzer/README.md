# Text Analyzer

This project is a simple web-based text analysis tool built with Flask and Vanilla JS. It demonstrates how to decouple data processing steps using the Pipe & Filter architectural pattern.

## What is Pipe & Filter?

The Pipe & Filter pattern is a software architecture where data flows sequentially through a series of independent processing components (filters) connected by channels (pipes). Each filter performs a single, specific transformation on the data and passes it to the next step, allowing you to easily add, remove, or reorder steps without breaking the rest of the system.

## Pipeline Architecture

```text
[ Raw Text Input ]
        │
        ▼
 (1) Get Input (Strips whitespace)
        │
        ▼
 (2) Clean & Tokenize (Removes punctuation & splits to words)
        │
        ▼
 (3) Remove Stopwords (Removes common words like "the", "is") ──┐ (Optional)
        │                                                       │
        ▼ <─────────────────────────────────────────────────────┘
 (4) Count Words (Returns top 10 word counts)
        │
        ▼
[ JSON Output ]
```

## Project Structure

```text
text-analyzer/
│
├── app.py               # Minimal Flask backend serving the UI and API
├── pipeline.py          # Core logic containing the filters and run_pipeline
├── requirements.txt     # Python dependencies (Flask)
└── templates/
    └── index.html       # Frontend UI with inline CSS/JS (Dark/Mint theme)
```

## How to Run

1. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Start the Flask application:
   ```bash
   python app.py
   ```
3. Open your browser and navigate to `http://127.0.0.1:5050`

## Example Input / Output

**Input Text:**
> "The cat is on the mat. The cat is happy."

**Expected JSON Output (with all filters enabled):**
```json
{
  "results": [
    {
      "name": "Get Input",
      "output": "The cat is on the mat. The cat is happy.",
      "skipped": false
    },
    {
      "name": "Clean & Tokenize",
      "output": ["the", "cat", "is", "on", "the", "mat", "the", "cat", "is", "happy"],
      "skipped": false
    },
    {
      "name": "Remove Stopwords",
      "output": ["cat", "mat", "cat", "happy"],
      "skipped": false
    },
    {
      "name": "Count Words",
      "output": [["cat", 2], ["mat", 1], ["happy", 1]],
      "skipped": false
    }
  ]
}
```
