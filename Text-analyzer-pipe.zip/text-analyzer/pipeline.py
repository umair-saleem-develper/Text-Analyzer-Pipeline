import string
from collections import Counter

def get_input(text):
    """Removes leading and trailing whitespace from the text."""
    return text.strip()

def clean_and_tokenize(text):
    """Converts to lowercase, removes punctuation, and splits into words."""
    text = text.lower()
    # Replace punctuation with nothing
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text.split()

def remove_stopwords(words):
    """Removes common, uninformative words like 'the', 'is', 'on'."""
    # A small built-in list of common English stopwords
    stopwords = {'the', 'is', 'on', 'a', 'an', 'and', 'to', 'in', 'of', 'that', 'it', 'this'}
    return [word for word in words if word not in stopwords]

def count_words(words):
    """Counts how many times each word appears and returns the top 10."""
    return Counter(words).most_common(10)

# The Pipe & Filter configuration list. 
# To add or remove a filter, you only need to change this list.
FILTERS = [
    ("Get Input", get_input),
    ("Clean & Tokenize", clean_and_tokenize),
    ("Remove Stopwords", remove_stopwords),
    ("Count Words", count_words)
]

def run_pipeline(text, filters=FILTERS, enabled=None):
    """Runs data through each filter in sequence and records intermediate results."""
    results = []
    current_data = text
    
    for name, func in filters:
        if enabled is not None and name not in enabled:
            results.append({"name": name, "output": None, "skipped": True})
            continue
            
        current_data = func(current_data)
        results.append({"name": name, "output": current_data, "skipped": False})
        
    return results

if __name__ == "__main__":
    # Test it in the terminal
    test_text = "The cat is on the mat. The cat is happy."
    print(f"Input text: '{test_text}'\n")
    
    pipeline_results = run_pipeline(test_text)
    
    for step in pipeline_results:
        print(f"--- Filter: {step['name']} ---")
        print(f"Output: {step['output']}\n")
