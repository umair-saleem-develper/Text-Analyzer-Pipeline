from flask import Flask, render_template, request, jsonify
from pipeline import run_pipeline

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json(force=True, silent=True)
    if not data or 'text' not in data:
        return jsonify({'error': 'No text provided'}), 400
    
    enabled = data.get('enabled_filters')
    results = run_pipeline(data['text'], enabled=enabled)
    return jsonify({'results': results})

if __name__ == '__main__':
    app.run(port=5050, debug=True)
